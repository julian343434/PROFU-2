Integrantes: 
Maykoll Gomez
Nelson Arango

Link del draw.io:
https://drive.google.com/file/d/18CkfBLgmguzygdtocqZsXblO6ig5HOi8/view?usp=sharing