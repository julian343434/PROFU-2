/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DataBase;

/**
 *
 * @author Especializacion
 */
public class ConnectDataBase {

    public ConnectDataBase() {
        System.out.println("conectando a la base de datos");
    }
    
}
