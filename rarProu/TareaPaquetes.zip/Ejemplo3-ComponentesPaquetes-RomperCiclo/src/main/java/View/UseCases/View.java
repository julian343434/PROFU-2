package View.UseCases;

public abstract class View {
    public abstract void show();
}

