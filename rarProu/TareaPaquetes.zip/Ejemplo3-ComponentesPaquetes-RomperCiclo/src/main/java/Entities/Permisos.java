
package Entities;


public interface Permisos {
    public void validarPermisos();
}
